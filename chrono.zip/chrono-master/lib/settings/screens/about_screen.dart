import 'package:clock_app/navigation/widgets/app_top_bar.dart';
import 'package:clock_app/settings/screens/licenses.dart';
import 'package:clock_app/settings/types/setting_link.dart';
import 'package:clock_app/settings/widgets/setting_page_link_card.dart';
import 'package:clock_app/system/data/app_info.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

const String _developerName = 'Manav Raj';
const String _githubUrl = 'https://github.com/RichardDawkinsIN';
const String _telegramHandle = '@RichardDawkinsIN';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme colorScheme = theme.colorScheme;
    final TextTheme textTheme = theme.textTheme;

    return Scaffold(
      appBar: AppTopBar(
        title: AppLocalizations.of(context)!.aboutSettingGroup,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            children: [
              const SizedBox(height: 24),
              ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: Image.asset('assets/images/logo.png',
                    width: 128, height: 128),
              ),
              const SizedBox(height: 20),
              Text(
                'Manav Alarm',
                style: textTheme.headlineMedium?.copyWith(
                  color: colorScheme.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Version ${packageInfo?.version ?? '1.0.0'}',
                style: textTheme.bodyLarge
                    ?.copyWith(color: colorScheme.onBackground),
              ),
              const SizedBox(height: 32),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 8),
                  child: Text(
                    'CREDITS',
                    style: textTheme.labelLarge?.copyWith(
                      color: colorScheme.primary,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: colorScheme.surface,
                  borderRadius: BorderRadius.circular(20),
                ),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  children: [
                    const _CreditRow(
                      icon: Icons.person_rounded,
                      title: 'Developer',
                      value: _developerName,
                    ),
                    Divider(
                        height: 1, color: colorScheme.onSurface.withOpacity(0.15)),
                    const _CreditRow(
                      icon: Icons.code_rounded,
                      title: 'GitHub',
                      value: _githubUrl,
                      copyable: true,
                    ),
                    Divider(
                        height: 1, color: colorScheme.onSurface.withOpacity(0.15)),
                    const _CreditRow(
                      icon: Icons.send_rounded,
                      title: 'Telegram',
                      value: _telegramHandle,
                      copyable: true,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Made with Flutter by $_developerName',
                style: textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onBackground.withOpacity(0.6),
                ),
              ),
              const SizedBox(height: 16),
              SettingPageLinkCard(
                  setting: SettingPageLink(
                      "Open Source Licenses",
                      (context) => AppLocalizations.of(context)!
                          .openSourceLicensesSetting,
                      const LicensesScreen())),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

class _CreditRow extends StatelessWidget {
  const _CreditRow({
    required this.icon,
    required this.title,
    required this.value,
    this.copyable = false,
  });

  final IconData icon;
  final String title;
  final String value;
  final bool copyable;

  @override
  Widget build(BuildContext context) {
    final ColorScheme colorScheme = Theme.of(context).colorScheme;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          Icon(icon, color: colorScheme.primary),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: textTheme.titleMedium
                        ?.copyWith(color: colorScheme.primary)),
                const SizedBox(height: 2),
                Text(value,
                    style: textTheme.bodyMedium
                        ?.copyWith(color: colorScheme.onSurface)),
              ],
            ),
          ),
          if (copyable)
            IconButton(
              icon: Icon(Icons.copy_rounded, color: colorScheme.primary),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: value));
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('$title copied to clipboard')));
              },
            ),
        ],
      ),
    );
  }
}
