import 'package:flutter/material.dart';

/// Colourful gradient backdrop shown behind the whole app when a style theme
/// with a glass effect (Frost Blur > 0) is active. The frosted cards blur this.
class GlassBackground extends StatelessWidget {
  const GlassBackground({super.key, required this.child});

  final Widget child;

  static Color _shift(Color color, double hueShift) {
    final hsl = HSLColor.fromColor(color);
    return hsl.withHue((hsl.hue + hueShift) % 360).toColor();
  }

  Widget _blob(Color color, double size) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color.withOpacity(0.55), color.withOpacity(0)],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color bg = scheme.background;
    final Color accent = scheme.primary;
    final bool isDark = bg.computeLuminance() < 0.4;
    final Color second = _shift(accent, 70);
    final Color third = _shift(accent, -70);

    return Stack(
      alignment: Alignment.topLeft,
      textDirection: TextDirection.ltr,
      children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color.alphaBlend(accent.withOpacity(isDark ? 0.35 : 0.28), bg),
                  bg,
                  Color.alphaBlend(second.withOpacity(isDark ? 0.30 : 0.22), bg),
                ],
              ),
            ),
          ),
        ),
        Positioned(top: -120, left: -90, child: _blob(accent, 380)),
        Positioned(bottom: -150, right: -110, child: _blob(second, 440)),
        Positioned(top: 260, right: -140, child: _blob(third, 320)),
        Positioned.fill(child: child),
      ],
    );
  }
}
