enum RangeInterval {
  daily,
  weekly,
}
