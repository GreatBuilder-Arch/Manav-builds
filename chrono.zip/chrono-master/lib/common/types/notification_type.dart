
enum ScheduledNotificationType {
  alarm,
  timer,
}



