import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:url_launcher/url_launcher.dart';

// ---------- App + credits ----------
const String kAppName = 'Kisan Alarm';
const MethodChannel kNative = MethodChannel('kisan/native');
const String kDevName = 'Manav Raj';
const String kGithub = 'https://github.com/RichardDawkinsIN';
const String kTelegramId = '@RichardDawkinsIN';
const String kTelegramUrl = 'https://t.me/RichardDawkinsIN';

const List<int> kMinPresets = [5, 10, 20, 30, 35, 40];
const List<int> kHourPresets = [1, 2, 3, 4, 5, 6];

const List<List<String>> kOnlineTones = [
  ['Alarm Clock', 'https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg'],
  ['Digital Watch', 'https://actions.google.com/sounds/v1/alarms/digital_watch_alarm_long.ogg'],
];

final FlutterLocalNotificationsPlugin notif = FlutterLocalNotificationsPlugin();
final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.system);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  await notif.initialize(const InitializationSettings(
    android: AndroidInitializationSettings('@drawable/ic_stat_alarm'),
  ));
  final p = await SharedPreferences.getInstance();
  themeMode.value = ThemeMode.values[(p.getInt('theme') ?? 0).clamp(0, 2)];
  runApp(const KisanApp());
}

// ---------- Themes (text color is set explicitly per mode) ----------
ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final text = dark ? const Color(0xFFA7F3D0) : const Color(0xFF0B3D2E);
  final bg = dark ? const Color(0xFF07130F) : const Color(0xFFF1FAF5);
  final card = dark ? const Color(0xFF0F2A21) : Colors.white;
  final accent = dark ? const Color(0xFF34D399) : const Color(0xFF047857);
  final scheme = ColorScheme.fromSeed(seedColor: const Color(0xFF10B981), brightness: b).copyWith(
    surface: card,
    surfaceContainerLow: card,
    surfaceContainer: card,
    surfaceContainerHigh: card,
    onSurface: text,
    onSurfaceVariant: text,
    primary: accent,
    onPrimary: dark ? const Color(0xFF04210F) : Colors.white,
    secondary: accent,
  );
  final base = ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: bg);
  return base.copyWith(
    textTheme: base.textTheme.apply(bodyColor: text, displayColor: text),
    iconTheme: IconThemeData(color: text),
    appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: text, elevation: 0, centerTitle: true),
  );
}

class KisanApp extends StatelessWidget {
  const KisanApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeMode,
      builder: (_, mode, __) => MaterialApp(
        title: kAppName,
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        home: const HomePage(),
      ),
    );
  }
}

// ---------- Home ----------
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // timer setup
  String unit = 'min'; // 'min' or 'hour'
  int amount = 10;
  bool repeat = false;
  String stepMode = 'minus'; // 'minus' = shrinks each ring, 'plus' = grows each ring
  int stepAmount = 0; // minutes; 0 = no change

  // sound
  String toneMode = 'system'; // 'system' or 'url'
  String toneUrl = '';
  String toneName = 'System default';
  String toneSoundUri = ''; // content:// uri of the downloaded tone (works offline)
  bool downloading = false;

  // runtime
  Duration remaining = Duration.zero;
  DateTime? firstEnd;
  DateTime? end;
  int occ = 0; // index of the ring we are waiting for
  int scheduledUpTo = 0; // how many rings are already scheduled as notifications
  Timer? ticker;
  bool running = false;
  bool finished = false;
  bool dialogOpen = false;
  int _gen = 0; // bumps on every start/cancel so stale async work can tell it is outdated
  final AudioPlayer player = AudioPlayer();

  Duration get total => unit == 'min' ? Duration(minutes: amount) : Duration(hours: amount);

  String get totalLabel => unit == 'min' ? '$amount min' : '$amount hour${amount == 1 ? '' : 's'}';

  // gap (in minutes) before ring number i. i = 0 is the first ring.
  Duration _interval(int i) {
    var m = total.inMinutes;
    if (repeat && stepAmount > 0) {
      m += (stepMode == 'plus' ? 1 : -1) * stepAmount * i;
    }
    if (m < 1) m = 1; // never go below 1 minute
    return Duration(minutes: m);
  }

  String _fmtMin(int m) {
    if (m >= 60 && m % 60 == 0) {
      final h = m ~/ 60;
      return '$h hour${h == 1 ? '' : 's'}';
    }
    if (m > 60) return '${m ~/ 60}h ${m % 60}m';
    return '$m min';
  }

  String _ringLabel(int i) => _fmtMin(_interval(i).inMinutes);

  // In minus mode a ring only happens while its gap is at least one full step
  // (10 min, step 3 -> 10, 7, 4 ring; the leftover 1 min is skipped) and the
  // alarm then stops for good. The first ring always happens.
  int? get maxRings {
    if (!repeat || stepAmount <= 0 || stepMode != 'minus') return null;
    final n = total.inMinutes ~/ stepAmount;
    return n < 1 ? 1 : n;
  }

  String get stepPreview {
    final mr = maxRings;
    final n = mr == null ? 4 : (mr < 4 ? mr : 4);
    final parts = [for (var i = 0; i < n; i++) _interval(i).inMinutes.toString()];
    if (mr != null && mr <= 4) return '${parts.join(' → ')} min → stop';
    return '${parts.join(' → ')} … min';
  }

  List<int> get presets => unit == 'min' ? kMinPresets : kHourPresets;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  @override
  void dispose() {
    ticker?.cancel();
    player.dispose();
    super.dispose();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      unit = p.getString('unit') == 'hour' ? 'hour' : 'min';
      amount = p.getInt('amount') ?? 10;
      repeat = p.getBool('repeat') ?? false;
      stepMode = p.getString('stepMode') == 'plus' ? 'plus' : 'minus';
      stepAmount = (p.getInt('stepAmount') ?? 0).clamp(0, 999);
      toneMode = p.getString('toneMode') ?? 'system';
      toneUrl = p.getString('toneUrl') ?? '';
      toneName = p.getString('toneName') ?? 'System default';
      toneSoundUri = p.getString('toneSoundUri') ?? '';
    });
    await _restoreRun(p);
    _askBackgroundOnce();
  }

  Future<void> _savePrefs() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('unit', unit);
    await p.setInt('amount', amount);
    await p.setBool('repeat', repeat);
    await p.setString('stepMode', stepMode);
    await p.setInt('stepAmount', stepAmount);
  }

  Future<void> _saveRun(int? firstEndMs) async {
    try {
      final p = await SharedPreferences.getInstance();
      if (firstEndMs == null) {
        await p.remove('runFirstEnd');
      } else {
        await p.setInt('runFirstEnd', firstEndMs);
      }
    } catch (_) {}
  }

  // App was closed or restarted while an alarm was running: pick it up again.
  Future<void> _restoreRun(SharedPreferences p) async {
    final ms = p.getInt('runFirstEnd');
    if (ms == null || running || !mounted) return;
    firstEnd = DateTime.fromMillisecondsSinceEpoch(ms);
    final now = DateTime.now();
    var k = 0;
    if (!repeat) {
      if (!firstEnd!.isAfter(now)) {
        await _saveRun(null);
        return;
      }
    } else {
      final mr = maxRings;
      while (!_occTime(k).isAfter(now)) {
        k++;
        if (mr != null && k >= mr) {
          await _saveRun(null);
          return;
        }
      }
    }
    _gen++;
    occ = k;
    end = _occTime(k);
    scheduledUpTo = k;
    setState(() {
      running = true;
      finished = false;
      remaining = end!.difference(now);
    });
    ticker?.cancel();
    ticker = Timer.periodic(const Duration(milliseconds: 100), _tick);
    _ensureScheduled();
  }

  void _setStep(int v) {
    if (running || v < 0 || v > 999) return;
    setState(() => stepAmount = v);
    _savePrefs();
  }

  void _setStepMode(String m) {
    if (running) return;
    setState(() => stepMode = m);
    _savePrefs();
  }

  Future<void> _saveTone(String mode, String url, String name, [String soundUri = '']) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('toneMode', mode);
    await p.setString('toneUrl', url);
    await p.setString('toneName', name);
    await p.setString('toneSoundUri', soundUri);
    if (!mounted) return;
    setState(() {
      toneMode = mode;
      toneUrl = url;
      toneName = name;
      toneSoundUri = soundUri;
    });
  }

  // Download the chosen online tone once, store it on the phone, use it as notification sound.
  Future<void> _downloadTone(String url, String name, [String? extHint]) async {
    setState(() => downloading = true);
    try {
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 40));
      if (res.statusCode != 200 || res.bodyBytes.isEmpty) throw Exception('HTTP ${res.statusCode}');
      final dir = await getTemporaryDirectory();
      if (res.bodyBytes.length > 10 * 1024 * 1024) throw Exception('file is too large');
      var ext = (extHint ?? url.split('?').first.split('.').last).toLowerCase();
      if (ext != 'ogg' && ext != 'mp3') ext = 'mp3';
      final safe = name.replaceAll(RegExp(r'[^A-Za-z0-9]'), '_');
      final f = File('${dir.path}/$safe.$ext');
      await f.writeAsBytes(res.bodyBytes);
      final uri = await kNative.invokeMethod<String>('saveNotificationSound', {'path': f.path, 'title': name});
      // new channel id per tone, because Android locks a channel's sound after creation
      await _saveTone('url', url, name, uri ?? '');
      _toast('Tone downloaded. It will ring even offline.');
    } catch (e) {
      _toast('Download failed, using system sound. ($e)');
      await _saveTone('system', '', 'System default');
    } finally {
      if (mounted) setState(() => downloading = false);
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  // ----- background permission -----
  Future<void> _askBackgroundOnce() async {
    final p = await SharedPreferences.getInstance();
    if (p.getBool('bgAsked') == true) return;
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    await _backgroundDialog();
    await p.setBool('bgAsked', true);
  }

  Future<void> _backgroundDialog() async {
    bool ok = false;
    try {
      ok = await kNative.invokeMethod<bool>('isIgnoringBattery') ?? false;
    } catch (_) {}
    if (ok || !mounted) return;
    final go = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Background permission'),
        content: const Text(
            'Tap "Allow" and remove battery optimization for this app, so the alarm always rings on time. '
            'Otherwise the phone may close the app in the background.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Later')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Allow')),
        ],
      ),
    );
    if (go == true) {
      try {
        await kNative.invokeMethod('requestIgnoreBattery');
      } catch (_) {}
    }
  }

  void _setUnit(String u) {
    if (running) return;
    setState(() {
      unit = u;
      amount = u == 'min' ? 10 : 1;
    });
    _savePrefs();
  }

  void _setAmount(int a) {
    if (running || a <= 0) return;
    setState(() => amount = a);
    _savePrefs();
  }

  // ----- notifications -----
  bool get _useFileTone => toneMode == 'url' && toneSoundUri.isNotEmpty;

  NotificationDetails _details() => NotificationDetails(
        android: AndroidNotificationDetails(
          _useFileTone ? 'kisan_tone_${toneSoundUri.hashCode.abs()}' : 'kisan_alarm_v1',
          kAppName,
          sound: _useFileTone ? UriAndroidNotificationSound(toneSoundUri) : null,
          channelDescription: 'Rings when your alarm time is up',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          audioAttributesUsage: AudioAttributesUsage.alarm,
          category: AndroidNotificationCategory.alarm,
          fullScreenIntent: true,
          additionalFlags: Int32List.fromList(<int>[4]), // insistent: keeps ringing
        ),
      );

  DateTime _occTime(int i) {
    var t = firstEnd!;
    for (var k = 1; k <= i; k++) {
      t = t.add(_interval(k));
    }
    return t;
  }

  Future<void> _scheduleAt(int i) async {
    final t = _occTime(i);
    final when = tz.TZDateTime.fromMillisecondsSinceEpoch(tz.UTC, t.millisecondsSinceEpoch);
    Future<void> go(AndroidScheduleMode mode) => notif.zonedSchedule(
          1 + i,
          kAppName,
          'Time is up! (${_ringLabel(i)})',
          when,
          _details(),
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        );
    try {
      await go(AndroidScheduleMode.exactAllowWhileIdle);
    } catch (_) {
      await go(AndroidScheduleMode.inexactAllowWhileIdle);
    }
  }

  Future<void> _ensureScheduled([int? g]) async {
    final gen = g ?? _gen;
    var target = repeat ? occ + 30 : 1;
    final mr = maxRings;
    if (mr != null && target > mr) target = mr;
    while (gen == _gen && running && scheduledUpTo < target) {
      final i = scheduledUpTo++; // claim the slot before awaiting (no skipped/double slots)
      try {
        await _scheduleAt(i);
      } catch (_) {}
      if (gen != _gen && !running) {
        try {
          await notif.cancel(1 + i); // run was turned off while this one was in flight
        } catch (_) {}
      }
    }
  }

  // ----- start / ring / stop -----
  Future<void> _start() async {
    if (total.inSeconds <= 0 || running) return;
    final gen = ++_gen;
    // switch the UI to "running" at once, so a second tap can never start a second run
    firstEnd = DateTime.now().add(_interval(0));
    end = firstEnd;
    occ = 0;
    scheduledUpTo = 0;
    _saveRun(firstEnd!.millisecondsSinceEpoch);
    setState(() {
      running = true;
      finished = false;
      remaining = _interval(0);
    });
    ticker?.cancel();
    ticker = Timer.periodic(const Duration(milliseconds: 100), _tick);

    // permissions + notification scheduling happen in the background
    try {
      final a = notif.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await a?.requestNotificationsPermission();
      await a?.requestExactAlarmsPermission();
    } catch (_) {}
    if (gen != _gen) return; // turned off meanwhile
    try {
      await notif.cancelAll();
    } catch (_) {}
    if (gen != _gen) return;
    await _ensureScheduled(gen);
  }

  void _tick(Timer t) {
    if (end == null) return;
    final now = DateTime.now();
    final left = end!.difference(now);
    final threshold = (toneMode == 'url' && !_useFileTone) ? const Duration(milliseconds: 400) : Duration.zero;
    if (left <= threshold) {
      if (repeat && now.difference(end!) > const Duration(seconds: 3)) {
        _skipPast(now); // app was in background, notification already rang
      } else {
        _ring();
      }
    } else if ((remaining - left).inMilliseconds.abs() >= 250) {
      setState(() => remaining = left); // fewer rebuilds = smoother app
    }
  }

  void _skipPast(DateTime now) {
    var k = 0;
    while (!_occTime(occ + k).isAfter(now)) {
      k++;
      final mr = maxRings;
      if (mr != null && occ + k >= mr) {
        _finishAll(); // every ring of the countdown is already over
        return;
      }
    }
    occ += k;
    end = _occTime(occ);
    _ensureScheduled();
    setState(() => remaining = end!.difference(now));
  }

  void _finishAll() {
    ticker?.cancel();
    _saveRun(null);
    if (!mounted) return;
    setState(() {
      running = false;
      finished = false;
      end = null;
      occ = 0;
      scheduledUpTo = 0;
    });
    _toast('Alarm finished: no more rings are left, so it has stopped.');
  }

  Future<void> _ring() async {
    final id = 1 + occ;
    final ringLabel = _ringLabel(occ);
    if (!mounted) return;
    final rep = repeat;
    final mr = maxRings;
    final last = rep && mr != null && occ >= mr - 1; // final ring in minus mode
    final cont = rep && !last; // will another ring follow?
    // synchronous part first, so the 100ms ticker never re-enters
    if (cont) {
      occ++;
      end = _occTime(occ);
    } else {
      ticker?.cancel();
      _saveRun(null);
    }
    setState(() {
      running = cont;
      finished = !cont;
      remaining = cont ? _interval(occ) : Duration.zero;
    });
    if (cont) _ensureScheduled();

    if (toneMode == 'url' && toneUrl.isNotEmpty && !_useFileTone) {
      try {
        await notif.cancel(id); // fallback: stream the online tone ourselves
        await player.setReleaseMode(ReleaseMode.loop);
        await player.play(UrlSource(toneUrl));
      } catch (_) {
        await notif.show(id, kAppName, 'Time is up! ($ringLabel)', _details());
      }
    }
    if (!mounted || dialogOpen) return;
    dialogOpen = true;
    final off = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        title: const Text("Time's up!"),
        content: Text(last
            ? 'That was the last alarm. The remaining gap is too small, so the alarm is now off for good.'
            : rep
            ? (stepAmount > 0
                ? 'Next alarm in ${_ringLabel(occ)}. It keeps repeating until you turn it off.'
                : 'Alarm repeats every $totalLabel until you turn it off.')
            : 'Your $totalLabel timer has finished.'),
        actions: [
          if (cont) TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Turn off alarm')),
          FilledButton(onPressed: () => Navigator.pop(c, false), child: Text(cont ? 'Stop this ring' : 'Stop')),
        ],
      ),
    );
    dialogOpen = false;
    await _silence();
    if (off == true) {
      await _cancel();
    } else if (!cont && mounted) {
      setState(() => finished = false);
    }
  }

  Future<void> _silence() async {
    await player.stop();
    final a = notif.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final act = await a?.getActiveNotifications() ?? <ActiveNotification>[];
    for (final n in act) {
      if (n.id != null) await notif.cancel(n.id!);
    }
  }

  Future<void> _cancel() async {
    _gen++;
    ticker?.cancel();
    _saveRun(null);
    // update the UI first, then clean up the notifications
    if (mounted) {
      setState(() {
        running = false;
        finished = false;
        end = null;
        occ = 0;
        scheduledUpTo = 0;
      });
    }
    try {
      await notif.cancelAll();
    } catch (_) {}
    try {
      await player.stop();
    } catch (_) {}
  }

  // ----- helpers / dialogs -----
  String _fmt(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  Future<void> _customDialog() async {
    final c = TextEditingController();
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(unit == 'min' ? 'Custom minutes' : 'Custom hours'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: InputDecoration(hintText: unit == 'min' ? 'e.g. 45' : 'e.g. 7', suffixText: unit == 'min' ? 'min' : 'hours'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, int.tryParse(c.text)), child: const Text('Set')),
        ],
      ),
    );
    if (v != null && v > 0) _setAmount(v);
  }

  Future<void> _customUrlDialog() async {
    final c = TextEditingController(text: toneUrl);
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Direct audio link'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(hintText: 'https://.../tone.mp3'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (v != null && v.startsWith('http')) await _downloadTone(v, 'Custom link');
  }

  Future<void> _openOnlineTones() async {
    final r = await Navigator.of(context).push<Map<String, String>>(
      MaterialPageRoute(builder: (_) => OnlineTonesPage(selectedUrl: toneMode == 'url' ? toneUrl : '')),
    );
    if (r != null && mounted) await _downloadTone(r['url']!, r['name']!, r['ext']);
  }

  void _toneSheet() {
    if (running) return;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 12),
          Text('Alarm sound', style: Theme.of(ctx).textTheme.titleLarge),
          ListTile(
            leading: const Icon(Icons.phone_android),
            title: const Text('System default'),
            trailing: toneMode == 'system' ? const Icon(Icons.check_circle) : null,
            onTap: () {
              _saveTone('system', '', 'System default');
              Navigator.pop(ctx);
            },
          ),
          ListTile(
            leading: const Icon(Icons.library_music),
            title: const Text('Online ringtones list'),
            subtitle: const Text('Search, preview, then download and set'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.pop(ctx);
              _openOnlineTones();
            },
          ),
          for (final t in kOnlineTones)
            ListTile(
              leading: const Icon(Icons.cloud_outlined),
              title: Text('Quick: ${t[0]}'),
              trailing: toneMode == 'url' && toneUrl == t[1] ? const Icon(Icons.check_circle) : null,
              onTap: () {
                Navigator.pop(ctx);
                _downloadTone(t[1], t[0]);
              },
            ),
          ListTile(
            leading: const Icon(Icons.link),
            title: const Text('Custom audio link'),
            onTap: () {
              Navigator.pop(ctx);
              _customUrlDialog();
            },
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Future<void> _cycleTheme() async {
    final next = ThemeMode.values[(themeMode.value.index + 1) % 3];
    themeMode.value = next;
    final p = await SharedPreferences.getInstance();
    await p.setInt('theme', next.index);
  }

  IconData _themeIcon(ThemeMode m) =>
      m == ThemeMode.light ? Icons.light_mode : (m == ThemeMode.dark ? Icons.dark_mode : Icons.brightness_auto);

  // ----- UI -----
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final curTotal = running ? _interval(occ) : total;
    final shown = running ? remaining : total;
    final progress = running && curTotal.inMilliseconds > 0 ? remaining.inMilliseconds / curTotal.inMilliseconds : 1.0;
    final isPreset = presets.contains(amount);
    final dim = cs.onSurface.withAlpha(150);

    return Scaffold(
      appBar: AppBar(
        title: const Text(kAppName, style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          ValueListenableBuilder<ThemeMode>(
            valueListenable: themeMode,
            builder: (_, m, __) => IconButton(tooltip: 'Theme', icon: Icon(_themeIcon(m)), onPressed: _cycleTheme),
          ),
          IconButton(
            tooltip: 'About',
            icon: const Icon(Icons.info_outline),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutPage())),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: Column(children: [
            const SizedBox(height: 8),
            SizedBox(
              width: 280,
              height: 280,
              child: CustomPaint(
                painter: RingPainter(
                  progress: progress.clamp(0.0, 1.0),
                  track: dark ? const Color(0xFF123428) : const Color(0xFFD1EBDD),
                  colors: dark
                      ? const [Color(0xFF34D399), Color(0xFF22D3EE), Color(0xFF34D399)]
                      : const [Color(0xFF047857), Color(0xFF0E9F8E), Color(0xFF047857)],
                ),
                child: Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(_fmt(shown), style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w300, letterSpacing: 1.5)),
                    const SizedBox(height: 4),
                    Text(
                      running ? (repeat ? 'REPEATING' : 'RUNNING') : (finished ? "TIME'S UP" : 'READY'),
                      style: TextStyle(fontSize: 13, letterSpacing: 2.5, color: cs.primary),
                    ),
                    if (unit == 'hour')
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(totalLabel, style: TextStyle(fontSize: 13, color: dim)),
                      ),
                  ]),
                ),
              ),
            ),
            const SizedBox(height: 24),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'min', label: Text('Minutes'), icon: Icon(Icons.timer_outlined)),
                ButtonSegment(value: 'hour', label: Text('Hours'), icon: Icon(Icons.schedule)),
              ],
              selected: {unit},
              onSelectionChanged: running ? null : (s) => _setUnit(s.first),
            ),
            const SizedBox(height: 16),
            Wrap(spacing: 10, runSpacing: 8, alignment: WrapAlignment.center, children: [
              for (final m in presets)
                ChoiceChip(
                  label: Text(unit == 'min' ? '$m min' : '$m hour${m == 1 ? '' : 's'}'),
                  selected: amount == m,
                  onSelected: running ? null : (_) => _setAmount(m),
                ),
              ChoiceChip(
                avatar: const Icon(Icons.edit, size: 16),
                label: Text(isPreset ? 'Manual' : '$totalLabel (manual)'),
                selected: !isPreset,
                onSelected: running ? null : (_) => _customDialog(),
              ),
            ]),
            const SizedBox(height: 12),
            Card(
              child: SwitchListTile(
                secondary: const Icon(Icons.repeat),
                title: const Text('Repeat alarm'),
                subtitle: Text(stepAmount > 0
                    ? 'Gap ${stepMode == 'minus' ? 'shrinks' : 'grows'} by $stepAmount min after every ring'
                    : 'Rings every $totalLabel until you turn it off'),
                value: repeat,
                onChanged: running
                    ? null
                    : (v) {
                        setState(() => repeat = v);
                        _savePrefs();
                      },
              ),
            ),
            if (repeat)
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: const [
                      Icon(Icons.swap_vert),
                      SizedBox(width: 12),
                      Text('Change on each repeat', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                    ]),
                    const SizedBox(height: 12),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'minus', label: Text('Decrease (−)'), icon: Icon(Icons.remove)),
                        ButtonSegment(value: 'plus', label: Text('Increase (+)'), icon: Icon(Icons.add)),
                      ],
                      selected: {stepMode},
                      onSelectionChanged: running ? null : (s) => _setStepMode(s.first),
                    ),
                    const SizedBox(height: 8),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      IconButton.filledTonal(
                        onPressed: running || stepAmount <= 0 ? null : () => _setStep(stepAmount - 1),
                        icon: const Icon(Icons.remove),
                      ),
                      SizedBox(
                        width: 110,
                        child: Text(stepAmount == 0 ? 'Off' : '$stepAmount min',
                            textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
                      ),
                      IconButton.filledTonal(
                        onPressed: running ? null : () => _setStep(stepAmount + 1),
                        icon: const Icon(Icons.add),
                      ),
                    ]),
                    const SizedBox(height: 4),
                    Center(
                      child: Text(
                        stepAmount == 0
                            ? 'Same gap every time (0 = no change)'
                            : (stepMode == 'minus' ? '$stepPreview\nAlarm stops for good when the gap gets smaller than the step' : stepPreview),
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 13, color: dim),
                      ),
                    ),
                  ]),
                ),
              ),
            const SizedBox(height: 4),
            Card(
              child: ListTile(
                leading: const Icon(Icons.music_note),
                title: const Text('Alarm sound'),
                subtitle: Text(downloading ? 'Downloading...' : (_useFileTone ? '$toneName (saved on phone)' : toneName)),
                trailing: downloading
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                    : const Icon(Icons.chevron_right),
                onTap: downloading ? null : _toneSheet,
              ),
            ),
            const SizedBox(height: 4),
            Card(
              child: ListTile(
                leading: const Icon(Icons.battery_saver),
                title: const Text('Background permission'),
                subtitle: const Text('Remove battery optimization so the alarm keeps working'),
                trailing: const Icon(Icons.chevron_right),
                onTap: _backgroundDialog,
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 58,
              child: running
                  ? OutlinedButton.icon(
                      onPressed: _cancel,
                      icon: const Icon(Icons.alarm_off),
                      label: const Text('Turn off alarm', style: TextStyle(fontSize: 18)),
                      style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))),
                    )
                  : FilledButton.icon(
                      onPressed: _start,
                      icon: const Icon(Icons.alarm_on, size: 26),
                      label: const Text('Start alarm', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                      style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))),
                    ),
            ),
            const SizedBox(height: 18),
            Text('Made by $kDevName', style: TextStyle(fontSize: 12, color: dim)),
          ]),
        ),
      ),
    );
  }
}

// ---------- Progress ring ----------
class RingPainter extends CustomPainter {
  final double progress;
  final Color track;
  final List<Color> colors;
  RingPainter({required this.progress, required this.track, required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 14;
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 16
          ..color = track);
    final fg = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(colors: colors, transform: const GradientRotation(-math.pi / 2)).createShader(rect);
    canvas.drawArc(rect, -math.pi / 2, 2 * math.pi * progress, false, fg);
  }

  @override
  bool shouldRepaint(RingPainter old) => old.progress != progress || old.track != track || old.colors != colors;
}

// ---------- About ----------
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  Future<void> _open(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dim = cs.onSurface.withAlpha(150);
    return Scaffold(
      appBar: AppBar(title: const Text('About', style: TextStyle(fontWeight: FontWeight.w700))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const SizedBox(height: 10),
        Center(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: Image.asset('assets/logo.png', width: 112, height: 112, fit: BoxFit.cover),
          ),
        ),
        const SizedBox(height: 16),
        const Center(child: Text(kAppName, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700))),
        const Center(child: Text('Version 5.4.1')),
        const SizedBox(height: 28),
        Text('CREDITS', style: TextStyle(letterSpacing: 2, fontSize: 12, color: cs.primary)),
        const SizedBox(height: 8),
        Card(
          child: Column(children: [
            const ListTile(leading: Icon(Icons.person), title: Text('Developer'), subtitle: Text(kDevName)),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.code),
              title: const Text('GitHub'),
              subtitle: const Text(kGithub),
              trailing: IconButton(
                icon: const Icon(Icons.copy, size: 20),
                onPressed: () => Clipboard.setData(const ClipboardData(text: kGithub)),
              ),
              onTap: () => _open(kGithub),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.send),
              title: const Text('Telegram'),
              subtitle: const Text(kTelegramId),
              trailing: IconButton(
                icon: const Icon(Icons.copy, size: 20),
                onPressed: () => Clipboard.setData(const ClipboardData(text: kTelegramId)),
              ),
              onTap: () => _open(kTelegramUrl),
            ),
          ]),
        ),
        const SizedBox(height: 24),
        Center(child: Text('Made with Flutter by $kDevName', style: TextStyle(fontSize: 12, color: dim))),
      ]),
    );
  }
}


// ---------- Online ringtone browser (Openverse: open-source audio search API, no key) ----------
class OnlineTonesPage extends StatefulWidget {
  final String selectedUrl;
  const OnlineTonesPage({super.key, this.selectedUrl = ''});
  @override
  State<OnlineTonesPage> createState() => _OnlineTonesPageState();
}

class _Tone {
  final String title, creator, url, ext, license;
  final int seconds; // 0 = unknown
  _Tone(this.title, this.creator, this.url, this.ext, this.license, this.seconds);
}

class _OnlineTonesPageState extends State<OnlineTonesPage> {
  static const chips = ['alarm', 'ringtone', 'bell', 'rooster', 'bird', 'clock', 'phone ring', 'temple bell', 'siren', 'chime'];
  final TextEditingController qc = TextEditingController(text: 'alarm');
  final AudioPlayer preview = AudioPlayer();
  final List<_Tone> tones = [];
  bool loading = false;
  bool hasMore = false;
  String? error;
  int page = 0;
  String query = 'alarm';
  String? playing;

  @override
  void initState() {
    super.initState();
    preview.onPlayerComplete.listen((_) {
      if (mounted) setState(() => playing = null);
    });
    _search('alarm');
  }

  @override
  void dispose() {
    preview.dispose();
    qc.dispose();
    super.dispose();
  }

  Future<void> _search(String q, {bool more = false}) async {
    q = q.trim();
    if (q.isEmpty || loading) return;
    setState(() {
      loading = true;
      error = null;
      if (!more) {
        tones.clear();
        page = 0;
        query = q;
        qc.text = q;
      }
    });
    try {
      var added = 0;
      var tries = 0;
      // some results are filtered out (too long / wrong format), so look at up to 3 pages
      while (added == 0 && tries < 3) {
        tries++;
        page++;
        final uri = Uri.https('api.openverse.org', '/v1/audio/', {'q': query, 'page_size': '20', 'page': '$page'});
        final res = await http.get(uri, headers: {'User-Agent': 'KisanAlarm/5.3', 'Accept': 'application/json'}).timeout(const Duration(seconds: 20));
        if (res.statusCode == 429) throw Exception('Too many searches, please try again in a while');
        if (res.statusCode != 200) throw Exception('Server error ${res.statusCode}');
        final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
        final list = (data['results'] as List?) ?? const [];
        final pages = (data['page_count'] as num?)?.toInt() ?? page;
        hasMore = list.length >= 20 && page < pages;
        for (final r in list) {
          if (r is! Map) continue;
          final url = (r['url'] ?? '').toString();
          if (!url.startsWith('http')) continue;
          var ext = (r['filetype'] ?? url.split('?').first.split('.').last).toString().toLowerCase();
          if (ext != 'mp3' && ext != 'ogg') {
            if (r['filetype'] != null || ext.length <= 4) continue; // wav/flac etc. not supported
            ext = 'mp3';
          }
          final ms = (r['duration'] as num?)?.toInt() ?? 0;
          if (ms > 90000) continue; // long music is not a ringtone
          if (tones.any((t) => t.url == url)) continue;
          final lic = '${(r['license'] ?? '').toString().toUpperCase()} ${(r['license_version'] ?? '').toString()}'.trim();
          tones.add(_Tone(
            (r['title'] ?? 'Untitled').toString().trim().isEmpty ? 'Untitled' : (r['title']).toString().trim(),
            (r['creator'] ?? '').toString(),
            url,
            ext,
            lic.isEmpty ? '' : 'CC $lic',
            (ms / 1000).round(),
          ));
          added++;
        }
        if (!hasMore) break;
      }
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _togglePreview(_Tone t) async {
    try {
      if (playing == t.url) {
        await preview.stop();
        setState(() => playing = null);
        return;
      }
      await preview.stop();
      setState(() => playing = t.url);
      await preview.setReleaseMode(ReleaseMode.stop);
      await preview.play(UrlSource(t.url));
    } catch (_) {
      if (mounted) {
        setState(() => playing = null);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not play this tone')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final dim = Theme.of(context).colorScheme.onSurface.withOpacity(0.65);
    return Scaffold(
      appBar: AppBar(title: const Text('Online ringtones')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
          child: TextField(
            controller: qc,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) => _search(v),
            decoration: InputDecoration(
              hintText: 'Search: alarm, bell, rooster...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(icon: const Icon(Icons.arrow_forward), onPressed: () => _search(qc.text)),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
            ),
          ),
        ),
        SizedBox(
          height: 44,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: chips.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) => ActionChip(label: Text(chips[i]), onPressed: () => _search(chips[i])),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 24),
            children: [
              if (error != null)
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    Text(error!, textAlign: TextAlign.center),
                    const SizedBox(height: 8),
                    OutlinedButton(onPressed: () => _search(query, more: tones.isNotEmpty), child: const Text('Try again')),
                  ]),
                ),
              if (!loading && error == null && tones.isEmpty)
                const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('No tones found. Try a different word.'))),
              for (final t in tones)
                Card(
                  child: ListTile(
                    leading: IconButton.filledTonal(
                      icon: Icon(playing == t.url ? Icons.stop : Icons.play_arrow),
                      onPressed: () => _togglePreview(t),
                    ),
                    title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(
                      [if (t.creator.isNotEmpty) t.creator, if (t.seconds > 0) '${t.seconds}s', if (t.license.isNotEmpty) t.license].join(' • '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 12, color: dim),
                    ),
                    trailing: widget.selectedUrl == t.url
                        ? const Icon(Icons.check_circle)
                        : FilledButton(
                            onPressed: () {
                              preview.stop();
                              Navigator.pop(context, {'url': t.url, 'name': t.title, 'ext': t.ext});
                            },
                            child: const Text('Set'),
                          ),
                  ),
                ),
              if (loading) const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator())),
              if (!loading && hasMore && tones.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: OutlinedButton(onPressed: () => _search(query, more: true), child: const Text('Show more tones')),
                ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text('Source: Openverse (open-licensed audio). The tone is saved on your phone, so it rings offline too.',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: dim)),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
