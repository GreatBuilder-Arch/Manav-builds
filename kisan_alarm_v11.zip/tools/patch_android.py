import os, re, glob

# ---------- AndroidManifest ----------
m = 'android/app/src/main/AndroidManifest.xml'
s = open(m, encoding='utf-8').read()

perms = ['INTERNET', 'POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'USE_EXACT_ALARM',
         'VIBRATE', 'WAKE_LOCK', 'USE_FULL_SCREEN_INTENT',
         'RECEIVE_BOOT_COMPLETED', 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
         'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_SPECIAL_USE']
add = ''.join('    <uses-permission android:name="android.permission.%s"/>\n' % p
              for p in perms if 'android.permission.%s"' % p not in s)
s = s.replace('<application', add + '    <application', 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="Kisan Alarm"', s, 1)

receivers = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ActionBroadcastReceiver" />
"""
s = s.replace('</application>', receivers + '    </application>', 1)

view_q = """    <intent>
      <action android:name="android.intent.action.VIEW" />
      <data android:scheme="https" />
    </intent>
"""
if '</queries>' in s:
    s = s.replace('</queries>', view_q + '  </queries>', 1)
else:
    s = s.replace('</manifest>', '  <queries>\n' + view_q + '  </queries>\n</manifest>', 1)

# make the app show over the lock screen when the alarm fires
s = re.sub(r'<activity\b', '<activity android:showWhenLocked="true" android:turnScreenOn="true"', s, 1)

open(m, 'w', encoding='utf-8').write(s)

# ---------- Gradle: desugaring + SDK levels ----------
for f in ['android/app/build.gradle.kts', 'android/app/build.gradle']:
    if not os.path.exists(f):
        continue
    g = open(f, encoding='utf-8').read()
    kts = f.endswith('.kts')
    if kts:
        g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', g, 1)
        g = re.sub(r'compileSdk\s*=\s*[^\n]+', 'compileSdk = 36', g, 1)
        g = re.sub(r'targetSdk\s*=\s*[^\n]+', 'targetSdk = 36', g, 1)
        g += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    else:
        g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        coreLibraryDesugaringEnabled true', g, 1)
        g = re.sub(r'compileSdk(Version)?\s*=?\s*[^\n]+', 'compileSdk 36', g, 1)
        g = re.sub(r'targetSdk(Version)?\s*=?\s*[^\n]+', 'targetSdk 36', g, 1)
        g += '\ndependencies {\n    coreLibraryDesugaring "com.android.tools:desugar_jdk_libs:2.1.4"\n}\n'
    open(f, 'w', encoding='utf-8').write(g)

# ---------- Kotlin: native channel to save a downloaded tone as a notification sound ----------
kt = glob.glob('android/app/src/main/kotlin/**/MainActivity.kt', recursive=True)
assert kt, 'MainActivity.kt not found'
kt = kt[0]
src = open(kt, encoding='utf-8').read()
pkg = re.search(r'^package\s+([\w.]+)', src, re.M).group(1)
open(kt, 'w', encoding='utf-8').write("""package %s

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val channelName = "kisan/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "saveNotificationSound" -> {
                    try {
                        val path = call.argument<String>("path")!!
                        val title = call.argument<String>("title") ?: "Kisan Alarm Tone"
                        result.success(saveSound(path, title))
                    } catch (e: Exception) {
                        result.error("SAVE_FAILED", e.message, null)
                    }
                }
                "isIgnoringBattery" -> {
                    val pm = getSystemService(POWER_SERVICE) as PowerManager
                    result.success(pm.isIgnoringBatteryOptimizations(packageName))
                }
                "requestIgnoreBattery" -> {
                    try {
                        val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        i.data = Uri.parse("package:" + packageName)
                        startActivity(i)
                        result.success(true)
                    } catch (e: Exception) {
                        try {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            result.success(true)
                        } catch (e2: Exception) {
                            result.success(false)
                        }
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun saveSound(path: String, title: String): String {
        val src = File(path)
        val name = "KisanAlarm_" + src.name
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.TITLE, title)
            put(MediaStore.Audio.Media.MIME_TYPE, if (name.endsWith(".ogg")) "audio/ogg" else "audio/mpeg")
            put(MediaStore.Audio.Media.IS_NOTIFICATION, true)
            put(MediaStore.Audio.Media.IS_ALARM, true)
            put(MediaStore.Audio.Media.IS_MUSIC, false)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_NOTIFICATIONS + "/KisanAlarm")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        // remove an older copy of the same tone so we do not pile up duplicates
        try {
            resolver.delete(collection, MediaStore.Audio.Media.DISPLAY_NAME + "=?", arrayOf(name))
        } catch (_: Exception) {}

        val uri = resolver.insert(collection, values) ?: throw Exception("MediaStore insert failed")
        resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
        if (Build.VERSION.SDK_INT >= 29) {
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        }
        return uri.toString()
    }
}
""" % pkg)

print('Android patch done, package =', pkg)


# ---------- App icon (adaptive + legacy) and notification icon ----------
import shutil
src_res = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons', 'res')
dst_res = 'android/app/src/main/res'
if os.path.isdir(src_res):
    for root, _, files in os.walk(src_res):
        rel = os.path.relpath(root, src_res)
        os.makedirs(os.path.join(dst_res, rel), exist_ok=True)
        for fn in files:
            shutil.copy2(os.path.join(root, fn), os.path.join(dst_res, rel, fn))
    print('Custom icons installed')

# ---------- In-app logo (About page) ----------
logo = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets', 'logo.png')
if os.path.exists(logo):
    os.makedirs('assets', exist_ok=True)
    shutil.copy2(logo, 'assets/logo.png')
    print('Logo asset installed')
